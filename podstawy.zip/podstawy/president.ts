const President = (age: number, isCitizen: boolean) => {
    if (isCitizen && age >= 35) {
        return "Możesz być prezydentem";
    } else {
        return "Nie możesz być prezydentem";
    }
}

console.log(President(40, true));

