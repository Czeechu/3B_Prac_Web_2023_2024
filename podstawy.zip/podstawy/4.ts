const calculateTicketPrice = (x: number): number => {
    let cena: number;
    if (x >= 0 && x <= 15) {
        cena = 3;
    } else if (x >= 16 && x <= 40) {
        cena = 1.5 + (x * 0.20);
    } else {
        cena = 1 + (x * 0.10);
    }
    return cena;
}

const distance: number = 25;
console.log(`Cena biletu za ${distance} km wynosi: ${calculateTicketPrice(distance)} zł`);