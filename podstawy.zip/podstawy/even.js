"use strict";
const isEvenNumber = (num) => {
    if (num % 2 === 0) {
        return "parzysta";
    }
    else {
        return "nieparzysta";
    }
};
console.log(isEvenNumber(5));
