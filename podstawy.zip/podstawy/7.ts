const tekst: string = "Angular jest świetnym frameworkiem";

const countCharacters = (text: string): number => {
    return text.length;
}

console.log(`Liczba znaków w tekście: ${countCharacters(tekst)}`);