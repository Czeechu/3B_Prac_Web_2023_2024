const liczba: number = 42;

const TestNumber = (liczba:number ) => liczba *2;

console.log(TestNumber(liczba));
