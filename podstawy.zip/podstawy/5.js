"use strict";
const liczba = 42;
const TestNumber = (liczba) => liczba * 2;
console.log(TestNumber(liczba));
