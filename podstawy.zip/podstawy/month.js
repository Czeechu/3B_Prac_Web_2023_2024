"use strict";
const isValidMonth = (month) => {
    if (month >= 1 && month <= 12) {
        return "Poprawny numer miesiąca";
    }
    else {
        return "Niepoprawny numer miesiąca";
    }
};
console.log(isValidMonth(15));
