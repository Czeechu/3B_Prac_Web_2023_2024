"use strict";
const NumberOfPi = () => { return 3.14; };
console.log(NumberOfPi());
