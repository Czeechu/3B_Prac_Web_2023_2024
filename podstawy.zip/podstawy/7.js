"use strict";
const tekst = "Angular jest świetnym frameworkiem";
const countCharacters = (text) => {
    return text.length;
};
console.log(`Liczba znaków w tekście: ${countCharacters(tekst)}`);
