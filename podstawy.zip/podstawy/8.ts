interface Samochod{
    marka: string;
    rokProdukcji: number;
}

const car: Samochod = {
    marka: "Toyota",
    rokProdukcji: 2006
}

console.log(`Samochod ${car.marka} został wyprodukowany w ${car.rokProdukcji} r`);