"use strict";
const car = {
    marka: "Toyota",
    rokProdukcji: 2006
};
console.log(`Samochod ${car.marka} został wyprodukowany w ${car.rokProdukcji} r`);
